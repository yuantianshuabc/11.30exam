<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:81:"C:\Users\Lenovo\Desktop\11.30exam\public/../application/home\view\cart\index.html";i:1606702007;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>
<table>
    <tr>

    </tr>
</table>
</body>
</html>