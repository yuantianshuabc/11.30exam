<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:80:"C:\Users\Lenovo\Desktop\11.30exam\public/../application/home\view\cart\list.html";i:1606708344;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.0/dist/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
<style>
    #number{
        width: 30px;
        text-align: center;
    }
</style>
<script src="https://apps.bdimg.com/libs/jquery/2.1.4/jquery.min.js"></script>
<body>
<table class="table">
    <tr>
        <th>商品编号</th>
        <th>商品图片</th>
        <th>商品名称</th>
        <th>商品单价</th>
        <th>商品数量</th>
        <th>商品小计</th>
        <th>操作</th>
    </tr>
    <?php foreach($data as $v): ?>
    <tr>
        <td><?php echo $v['goods_id']; ?></td>
        <td><img src="<?php echo $v['goods_logo']; ?>" alt=""></td>
        <td><?php echo $v['goods_name']; ?></td>
        <td id="price"><?php echo $v['goods_price']; ?></td>
        <td>
            <a id="mins" href="javascript:void(0)">-</a>
            <input type="text" id="number" value="<?php echo $v['number']; ?>" initnumber="<?php echo $v['number']; ?>">
            <a id="plus" href="javascript:void(0)">+</a>
        </td>
        <td id="sma_sum"><?php echo $v['number']*$v['goods_price']; ?></td>
        <td><a href="">删除</a></td>
    </tr>
    <?php endforeach; ?>
</table>
<h2>总计：</h2><span id="sum"></span>
</body>
</html>
<script>

        $(function($) {
            // 加
            $("#plus").click(function () {
                var number=parseInt($("#number").val());
                var price=$("#price").html();

                $("#number").val(number+1);
                $("#sma_sum").html((number+1)*price);
                
            });

            // 减

            $('#mins').click(function () {
                var number=parseInt($("#number").val());

                if (number<=1){
                    alert('不能再减了');
                    return false
                }
                $("#number").val(number-1);
                var price=$("#price").html();
                $("#sma_sum").html((number-1)*price);
            });
            // 改
            $("#number").change(function () {
                var initnumber=$('#number').attr('initnumber');
                var number=$("#number").val();
                if (isNaN($("#number").val()))
                {
                    alert('请正确输入数量');
                    $("#number").val(initnumber);
                    return false
                }
                var price=$("#price").html();
                $("#sma_sum").html(number*price);
            })
        });



</script>