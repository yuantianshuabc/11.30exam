<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:82:"C:\Users\Lenovo\Desktop\11.30exam\public/../application/home\view\index\index.html";i:1606700195;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>
<form action="<?php echo url('home/Login/login'); ?>" method="post">
    用户名： <input type="text" name="username"><br>
    密码： <input type="password" name="password"><br>
    <input type="submit" value="登录">
</form>
</body>
</html>