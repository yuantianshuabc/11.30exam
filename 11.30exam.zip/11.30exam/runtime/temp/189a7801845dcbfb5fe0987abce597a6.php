<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:82:"C:\Users\Lenovo\Desktop\11.30exam\public/../application/home\view\goods\index.html";i:1606704277;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.0/dist/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

<body>
<h1>欢迎<?php echo \think\Session::get('user.username'); ?></h1>
<form action="<?php echo url('home/Cart/cartList'); ?>" method="post">
    <input type="hidden" name="user_id" value="<?php echo \think\Session::get('user.id'); ?>">
    <input type="submit" value="查看购物车">
</form>

<table class="table">
    <tr>
        <th>编号</th>
        <th>商品名称</th>
        <th>商品图片</th>
        <th>商品价格</th>
        <th>商品库存</th>
        <th>操作</th>
    </tr>
    <?php foreach($data as $v): ?>
    <tr>
        <td><?php echo $v['id']; ?></td>
        <td><?php echo $v['goods_name']; ?></td>
        <td><img src="<?php echo $v['goods_logo']; ?>" alt=""></td>
        <td><?php echo $v['goods_price']; ?></td>
        <td><?php echo $v['goods_num']; ?></td>
        <td>
            <form action="<?php echo url('home/Cart/index'); ?>" method="post">
                <input type="hidden" name="user_id" value="<?php echo \think\Session::get('user.id'); ?>">
                <input type="hidden" name="goods_id" value="<?php echo $v['id']; ?>">
                <input type="hidden" name="number" value="1">
                <input type="submit" value="加入购物车">
            </form>
        </td>
    </tr>
    <?php endforeach; ?>
</table>
</body>
</html>