<?php

namespace app\home\controller;

use think\Controller;

class Cart extends Controller
{
    public function index(){
        $param=input();
//        验证是否登录
        if (empty($param["user_id"])){
            return $this->error('请先登录','home/index/index');
        }
//        验证数据
        $result = $this->validate($param,[
           'goods_id|商品'=>'require',
           'number|数量'=>'require'
        ]);
        if (true !== $result){
            return  $this->error($result);
        }
//        购物车入库
        $user_id=$param['user_id'];
        $goods_id=$param['goods_id'];
        $res=\app\common\model\Cart::where('user_id',$user_id)->where('goods_id',$goods_id)->find();
        if ($res){
            //        如果该用户已经加购这件商品
            $cart=\app\common\model\Cart::where('user_id',$user_id)->where('goods_id',$goods_id)->setInc('number',$param['number']);
            return "<script>alert('加购成功');location.href='http://www.shop.com/home/goods/index.html'</script>";
        }else{
            $cart=\app\common\model\Cart::create($param,true);
            return "<script>alert('加购成功');location.href='http://www.shop.com/home/goods/index.html'</script>";
        }
    }
    public function cartList(){
        $param=input();
//        验证是否登录
        if (empty($param["user_id"])){
            return $this->error('请先登录','home/index/index');
        }

        $user_id=$param['user_id'];
        $res=collection(model('Cart')->join('User','Cart.user_id=User.id')
            ->join('Goods','Cart.goods_id=Goods.id')
            ->where('Cart.user_id',$user_id)
            ->select())->toArray();
        return view('list',['data'=>$res]);
    }
}
