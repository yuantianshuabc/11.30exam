<?php

namespace app\home\controller;

use app\common\model\User;
use think\Controller;
use think\Request;

class login extends Controller
{
    public function login(Request $request){
        $param=$request->param();
        $password=md5(md5($request->param('password')));
        $username=$request->param('username');
//        验证
        $validate=$this->validate($param,[
           'username|用户名'=>'require',
           'password|密码'=>'require'
        ]);
        if (true !== $validate){
            return $this->error($validate);
        }
//        登录
        $data=User::where('username',$username)->where('password',$password)->find();

        if ($data){
//            登录成功
            session('user',$data);
            return redirect('home/Goods/index');

        }else{
            return $this->error('用户名或密码错误');
        }
    }
}
