<?php
namespace app\home\controller;

class Index
{
    public function index()
    {
        return view();
    }
}
