<?php

namespace app\home\controller;

use think\Controller;

class Goods extends Controller
{
    public function index()
    {
       $data = \app\common\model\Goods::select();
        return view('',['data'=>$data]);
    }
}
